package com.example.tocay6conta;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class formularioII extends AppCompatActivity {
    private TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_ii

        );
        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);
        tv4 = (TextView) findViewById(R.id.tv4);
        tv5 = (TextView) findViewById(R.id.tv5);
        tv6 = (TextView) findViewById(R.id.tv6);
        String nombre = getIntent().getStringExtra("nombre");
        String apellido1 = getIntent().getStringExtra("apellido1");
        String apellido2 = getIntent().getStringExtra("apellido2");
        String direccion = getIntent().getStringExtra("direccion");
        String edad1 = getIntent().getStringExtra("edad1");
        String edad2 = getIntent().getStringExtra("edad2");
        tv1.setText("Dato 1" + nombre);
        tv2.setText("DATO 2" + apellido1);
        tv3.setText("DATO 3" + apellido2);
        tv4.setText("EDAD 1" + edad1);
        tv5.setText("EDAD 2" + edad2);
        tv6.setText("DIRECCION" + direccion);

    }
    public void regresar (View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
